import numpy as np
from sklearn.metrics import roc_auc_score, auc, precision_recall_curve, log_loss, accuracy_score


# Input file with format of word2vec output.
# Parse into a dict of {node: row_index} and a numpy array of embedding vectors
def parse_embedding(input_file):
    with open(input_file, "r") as f_in:
        num_nodes, dim = map(int, f_in.readline().strip().split())
        node_index_dict = {}  # {node: row_index}, where type(node) == str, type(row_index) == int
        embedding_matrix = np.zeros((num_nodes, dim), dtype=np.float_)
        idx = 0
        for line in f_in:
            line_split = line.strip().split()
            cur_name = line_split[0]
            node_index_dict[cur_name] = idx
            embedding_matrix[idx] = np.asarray(line_split[1:], dtype=np.float_)
            idx += 1

    assert idx == num_nodes, "Node number does not match."
    return node_index_dict, embedding_matrix


# Parse into a dict of {user_name: node} and a numpy array of embedding vectors
def read_user_node_map(input_file):
    user_node_dict = {}  # {user_name: node}, where type(user_name) == str, type(node) == str
    with open(input_file, "r") as f_in:
        for line in f_in:
            line_split = line.strip().split()
            if len(line_split) != 2:
                print "Unexpected line encountered:", line_split
                continue
            name, node = line_split
            user_node_dict[name] = node
    return user_node_dict


# Get number of lines in a file
def len_file(input_file):
    with open(input_file) as f:
        for i, l in enumerate(f):
            pass
    return i + 1


# Return a list of metrics given label and prediction
# Metrics used: ROC-AUC, AUPRC
def metrics_list(y_true, y_scores):
    if sum(y_true) == 0 or sum(y_true) == len(y_true):  # ignore the case with all positive or all negative
        return None
    rocauc = roc_auc_score(y_true, y_scores)
    precision, recall, _ = precision_recall_curve(y_true, y_scores)
    auprc = auc(recall, precision)
    return [rocauc, auprc]


# Return a list of metrics for multi-class classification
def multi_class_metrics_list(y_true, y_scores, y_pred):
    # find weights by class
    class_list, count_list = np.unique(y_true, return_counts=True)  # class_list is sorted by np.unique and assumed to be [0, 1, ..., num_class-1]
    sample_class_count = np.zeros_like(y_true, dtype=np.float_)
    for class_i in xrange(len(class_list)):
        cur_class = class_list[class_i]
        assert cur_class == class_i
        cur_count = count_list[class_i]
        sample_class_count[y_true == cur_class] = float(cur_count)

    log_loss_simple = log_loss(y_true, y_scores)
    log_loss_balanced = log_loss(y_true, y_scores, sample_weight=1. / sample_class_count)

    accuracy_simple = accuracy_score(y_true, y_pred)
    accuracy_balanced = accuracy_score(y_true, y_pred, sample_weight=1. / sample_class_count)

    per_class_rocauc = []
    per_class_auprc = []
    for class_i in xrange(len(class_list)):
        cur_class = class_list[class_i]
        assert cur_class == class_i
        rocauc = roc_auc_score(y_true == cur_class, y_scores[:, class_i])
        precision, recall, _ = precision_recall_curve(y_true == cur_class, y_scores[:, class_i])
        auprc = auc(recall, precision)
        per_class_rocauc.append(rocauc)
        per_class_auprc.append(auprc)

    rocauc_uniform = np.average(per_class_rocauc)  # corresponding to balanced
    rocauc_weighted = np.average(per_class_rocauc, weights=count_list)  # corresponding to simple

    auprc_uniform = np.average(per_class_auprc)  # corresponding to balanced
    auprc_weighted = np.average(per_class_auprc, weights=count_list)  # corresponding to simple

    return [log_loss_simple, log_loss_balanced, accuracy_simple, accuracy_balanced,
            rocauc_uniform, rocauc_weighted, auprc_uniform, auprc_weighted]






