"""
For generating synthetic data using various off-the-shelf graph generation algorithms.
With four classes, and two views: black and red.
"""
import argparse
import networkx as nx
import os
from random import random

parser = argparse.ArgumentParser(description="Read in input and output filenames and parameters.")
parser.add_argument("--num-nodes-per-class", help="Number of nodes per class, yielding a total of four times of this number.", type=int, default=1000)
parser.add_argument("--m", nargs="?", help="Preferential attachment parameter m.", type=int, default=1)
parser.add_argument("--cvp", nargs="?", help="Intrusion probability.", type=float, default=0)
parser.add_argument("--output-dir", help="Output directory.", type=str)
args = parser.parse_args()

num_nodes_per_class = args.num_nodes_per_class
m = args.m
p = args.p
cvp = args.cvp

data_name = "_".join(["pa", "nnpc"+str(num_nodes_per_class), "cvp"+str(cvp)])  # pa for preferential attachment

output_data_name_list = os.path.join(args.output_dir, "data_name_list.txt")  # to append, not to rewrite
output_data_path = os.path.join(args.output_dir, data_name)
if not os.path.exists(output_data_path):
    os.makedirs(output_data_path)
output_view_black = os.path.join(output_data_path, "network_synthetic_black.edgelist")
output_view_red = os.path.join(output_data_path, "network_synthetic_red.edgelist")
output_label = os.path.join(output_data_path, "synthetic_evaluation_core.csv")

with open(output_data_name_list, "a") as f_out:
    print >> f_out, data_name

rg2v_shift_factor_list = [[0, 0], [2, 2], [0, 1], [1, 2]] # random graph to view shift in terms of index

G_black = nx.Graph()
G_red = nx.Graph()

for rg_i in xrange(4): # 4 random graphs for 2 views
    # generate random graph
    cur_rg = nx.barabasi_albert_graph(num_nodes_per_class * 2, m)

    # assign to corresponding views with cvp considered
    is_red_primary = True if rg_i >= 2 else False
    for edge in cur_rg.edges():  # cur_rg is assumed to be undirected and the edge traverse visit each edge only once
        node_1, node_2 = edge
        node_1_mapped = node_1 + num_nodes_per_class * rg2v_shift_factor_list[rg_i][node_1 / num_nodes_per_class]
        node_2_mapped = node_2 + num_nodes_per_class * rg2v_shift_factor_list[rg_i][node_2 / num_nodes_per_class]
        if_cross_view = True if random() < cvp else False
        if is_red_primary is if_cross_view: # black if true
            G_black.add_edge(node_1_mapped, node_2_mapped)
        else:
            G_red.add_edge(node_1_mapped, node_2_mapped)

nx.write_edgelist(G_black, output_view_black, data=False)
nx.write_edgelist(G_red, output_view_red, data=False)

core_set = set(G_black.nodes()) & set(G_red.nodes())
with open(output_label, "w") as f_out:
    print >> f_out, "node,label"
    for node_j in xrange(4*num_nodes_per_class):
        if node_j in core_set:
            print >> f_out, str(node_j) + "," + str(node_j/num_nodes_per_class)
