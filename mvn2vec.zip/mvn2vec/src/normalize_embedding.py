import sys
import numpy as np
from sklearn.preprocessing import normalize

input_file = sys.argv[1]
assert ".emb" in input_file, \
    "The input file is assumed to be named ending with .emb."
output_file = input_file[:-4] + "_normalized.emb"

output_str = ""
with open(input_file, "r") as f_in:
    num_nodes, dim = map(int, f_in.readline().strip().split())
    line_k = 0
    for line in f_in:
        line_split = line.strip().split()
        assert dim == len(line_split)-1, "Embedding dimension does not match."
        cur_name = line_split[0]
        if cur_name == "</s>":
            num_nodes -= 1
            print "</s> is dropped."
            continue

        cur_emb = np.asarray(line_split[1:], dtype=np.float_)
        cur_emb_normalized = normalize([cur_emb])[0]  # normalize inputs and outputs matrices

        line_out = " ".join([cur_name] + [str(cur_emb_normalized[i]) for i in xrange(dim)]) + "\n"

        output_str += line_out

        line_k += 1
        if line_k % 10000 == 0:
            print "Line %d read and processed." % line_k

with open(output_file, "w") as f_out:
    f_out.write(" ".join([str(num_nodes), str(dim)]) + "\n")
    f_out.write(output_str)


