import sys
import os

input_file = sys.argv[1]
assert ("multi_view" in input_file or "independent" in input_file) and "embedding" in input_file, \
    "The input file is assumed to be named with multi_view_*_embedding or independent_embedding."
output_file = os.path.join(os.path.dirname(input_file), "concatenated_"+os.path.basename(input_file))

surface_name_set = set()
view_set = set() # assume to contain 0, 1, ..., len(view_set) - 1

emb_dict = {} # {str(name): str{space_sep'ed_emb}}
with open(input_file, "r") as f_in:
    num_nodes, dim = map(int, f_in.readline().strip().split())
    f_in.readline() # ignore the embedding for </s>
    line_k = 0
    for line in f_in:
        line_split = line.strip().split()
        assert dim == len(line_split)-1, "Embedding dimension does not match."
        cur_name = line_split[0]
        emb_dict[cur_name] = " ".join(line_split[1:])

        cur_view, cur_surface_name = cur_name.split(":")
        surface_name_set.add(cur_surface_name)
        view_set.add(cur_view)

        line_k += 1
        if line_k % 10000 == 0:
            print "Line %d read." % line_k

    assert num_nodes - 1 == len(emb_dict), "Number of nodes does not match." # note that </s> has been dropped

print "Embedding read done."

num_views = len(view_set)
# check validity of view_set
for view_i in xrange(num_views):
    assert str(view_i) in view_set, "Invalid view numbering."

all_zero_emb_str = " ".join(["0.0" for _ in xrange(dim)])
with open(output_file, "w") as f_out:
    f_out.write(" ".join([str(len(surface_name_set)), str(dim * num_views)]) + "\n")
    line_k = 0
    for cur_surface_name in surface_name_set:
        line_out = cur_surface_name
        for view_i in xrange(num_views):
            cur_name = str(view_i) + ":" + cur_surface_name
            if cur_name in emb_dict:
                line_out += " " + emb_dict[cur_name]
            else:
                line_out += " " + all_zero_emb_str
        line_out += "\n"
        f_out.write(line_out)

        line_k += 1
        if line_k % 10000 == 0:
            print "Line %d written." % line_k




