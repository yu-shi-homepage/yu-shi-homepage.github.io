import sys
import os
import numpy as np
from collections import defaultdict
from scipy.stats import sem

input_dir = sys.argv[1]


"""
Read in raw results
"""
results_per_model_dict = defaultdict(dict)
seed_set = set()
for file_name in os.listdir(input_dir):
    if "output" not in file_name or "parsed" in file_name:
        continue
    file_name_split = file_name.strip().split("_")
    for seed_position in xrange(len(file_name_split)):
        if "seed" in file_name_split[seed_position]:
            break
    cur_seed_str = file_name_split[seed_position][4:]
    cur_model_str = "_".join(file_name_split[:seed_position] + file_name_split[seed_position + 1:])

    input_file = input_dir + file_name
    with open(input_file, "r") as f_in:
        cur_results = map(float, f_in.readline().strip().split())
    num_metrics = len(cur_results)
    results_per_model_dict[cur_model_str][cur_seed_str] = cur_results
    seed_set.add(cur_seed_str)

"""
Re-org in nparray and calc mean
"""
#assert num_metrics == 4  # global ROC-AUC, global AUPRC, per-user ROC-AUC, per-user AUPRC, not necessarily true for classification tasks
seed_list = list(seed_set)
num_seeds = len(seed_list)

parsed_results_per_model_dict = {}
for cur_model_str in results_per_model_dict:
    cur_results_matrix = np.asarray([results_per_model_dict[cur_model_str][cur_seed_str]
                                     for cur_seed_str in seed_list], dtype=np.float_)
    cur_parsed_results_matrix = np.concatenate([cur_results_matrix, [sem(cur_results_matrix, axis=0)], [np.mean(cur_results_matrix, axis=0)]])
    parsed_results_per_model_dict[cur_model_str] = cur_parsed_results_matrix

"""
Output
"""
output_seed_index = input_dir + "seed_index.txt"
with open(output_seed_index, "w") as f_out:
    print >> f_out, seed_list

for cur_model_str in parsed_results_per_model_dict:
    output_cur_model = input_dir + "parsed_" + cur_model_str
    with open(output_cur_model, "w") as f_out:
        print >> f_out, "accuracy_on_test, log_loss_on_test, accuracy_on_validation, log_loss_on_validation:\n", parsed_results_per_model_dict[cur_model_str][-1]






