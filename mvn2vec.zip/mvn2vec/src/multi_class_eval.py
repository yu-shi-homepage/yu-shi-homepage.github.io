"""
For evaluating multi-class, instead of multi-label classification, on synthetic data.
Unlike previous evaluation codes requiring user-node-map, since synthetic data starts from edgelist files, where nodes are represented by node_number rather than names.
Input label filename format for each line from second on: node,label
Input label filename first line: "node,label"
Class labels assume to be of type int (e.g., 0,1,2,3)
"""

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from AuxiliaryFunctions import parse_embedding, len_file, multi_class_metrics_list
import time
import argparse
import os

parser = argparse.ArgumentParser(description="Read in input and output filenames.")
parser.add_argument("--input-embedding", nargs="?", help="Input embedding filename.", type=str)
parser.add_argument("--input-label", nargs="?", help="Input label filename.", type=str)
parser.add_argument("--output-dir", nargs="?", help="Output directory.", type=str)
parser.add_argument("--seed", default=3141492, nargs="?", help="Seed for randomization.", type=int)
parser.add_argument("--c", default=1.0, nargs="?", help="Regularization coefficient.", type=float)
parser.add_argument("--test-size", default=0.1, nargs="?", help="Ratio of test dataset size out of all data.", type=float)
args = parser.parse_args()

max_iter = 20000 # max iter in logit reg
rand_seed = args.seed
reg_C = args.c
test_size = args.test_size
validation_size_out_of_rest = test_size / (1 - test_size)
output_file = os.path.join(args.output_dir, "output_classification_seed"+str(args.seed)+"_"+os.path.basename(args.input_embedding)[:-4]+"_c"+str(reg_C)+".txt")

"""
Read and parse input data
"""
# read in others
time_start = time.time()
node_index_dict, embedding_matrix = parse_embedding(args.input_embedding)
time_end = time.time()
print "Embedding parsing done from file %s. Time used:" % args.input_embedding, (time_end - time_start)

"""
Generate feature table and multi-class label table
"""
num_total_records_input = len_file(args.input_label) - 1  # first line is header
y = np.zeros(num_total_records_input, dtype=np.int_)
X = np.zeros((num_total_records_input, embedding_matrix.shape[1]), dtype=np.float_)
num_node_not_in_embedding = 0
with open(args.input_label, "r") as f_in:
    column_names = f_in.readline().strip().split(",")
    assert column_names[0] == "node" and \
           column_names[1] == "label", "Column names do not align."
    row_i = 0
    num_rec_dropped = 0
    for line in f_in:
        line_split = line.strip().split(",")
        node = line_split[0]  # of type str
        label_str = line_split[1]  # of type str

        if node not in node_index_dict:
            num_rec_dropped += 1
            num_node_not_in_embedding += 1
            continue

        y[row_i] = int(label_str)
        X[row_i] = embedding_matrix[node_index_dict[node]]  # node is of type str

        row_i += 1

assert row_i + num_rec_dropped == num_total_records_input, "Number of records do not match."
y = y[:row_i]
X = X[:row_i]

time_end = time.time()
print "Evaluation data preparation done using record file %s. Time used:" % args.input_label, (time_end - time_start)

if num_node_not_in_embedding > 0:
    print "WARNING: %d nodes not in embedding. Should not happen if core user used." % num_node_not_in_embedding

# sample records by node
X_train_and_validation, X_test, y_train_and_validation, y_test = \
    train_test_split(X, y, test_size=test_size, random_state=rand_seed)
X_train, X_validation, y_train, y_validation = \
    train_test_split(X_train_and_validation, y_train_and_validation, test_size=validation_size_out_of_rest, random_state=rand_seed)

# train
time_start = time.time()
logit_model = LogisticRegression(class_weight="balanced", solver="sag", max_iter=max_iter, C=reg_C, multi_class="multinomial")
logit_model = logit_model.fit(X_train, y_train)
time_end = time.time()
print "Logistic regression training done. Time used:", (time_end - time_start)

proba_test = logit_model.predict_proba(X_test)
pred_test = logit_model.predict(X_test)

proba_validation = logit_model.predict_proba(X_validation)
pred_validation = logit_model.predict(X_validation)

"""
Evaluation
"""
with open(output_file, "w") as f_out:
    # Evaluate across all users
    global_results_test = multi_class_metrics_list(y_test, proba_test, pred_test)
    global_results_validation = multi_class_metrics_list(y_validation, proba_validation, pred_validation)

    # for easy parsing
    print >> f_out, "\t".join(map(str, [global_results_test[2], global_results_test[0], global_results_validation[2], global_results_validation[0]]))  # accuracy_on_test, log_loss_on_test, accuracy_on_validation, log_loss_on_validation

    print "accuracy_on_test, log_loss_on_test, accuracy_on_validation, log_loss_on_validation:\n", \
        [global_results_test[2], global_results_test[0], global_results_validation[2], global_results_validation[0]]
    print >> f_out, "accuracy_on_test, log_loss_on_test, accuracy_on_validation, log_loss_on_validation:\n", \
        [global_results_test[2], global_results_test[0], global_results_validation[2], global_results_validation[0]]
