#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <pthread.h>

#define MAX_STRING 200
#define EXP_TABLE_SIZE 1000
#define MAX_EXP 6
#define MAX_SENTENCE_LENGTH 1000
#define MAX_CODE_LENGTH 40

const int vocab_hash_size = 30000000;  // (May need to increase) Maximum 30 * 0.7 = 21M words in the vocabulary

typedef float real;                    // Precision of float numbers

struct vocab_word {
  long long cn;
  //int *point;
  //char *word, *code, codelen;
  char *word;
};

char train_file[MAX_STRING], output_file[MAX_STRING], output_file_context[MAX_STRING];
char save_vocab_file[MAX_STRING], read_vocab_file[MAX_STRING];
struct vocab_word *vocab;
int binary = 0, cbow = 0, debug_mode = 2, window = 5, min_count = 5, num_threads = 12, min_reduce = 1;
int *vocab_hash;
long long vocab_max_size = 1000, vocab_size = 0, layer1_size = 100;
long long train_words = 0, word_count_actual = 0, iter = 5, file_size = 0, classes = 0;
real alpha = 0.025, starting_alpha, sample = 1e-3, gam = 0.1, theta = 0.0;
real *syn0, *syn1, *syn1neg, *expTable;
int *neg_lock;  // lock for context embedding of each node regardless of view, to avoid the observed simultaneous access by multiple threads
clock_t start;

int hs = 0, negative = 5, g_theta_one = 0;
const int table_size_per_view = 1e8;
int *table;

long long num_lock_encountering = 0, num_lock_checking = 0;

int num_views = 0;  // assume the view numbers in input file are 0, 1, ..., (num_views - 1)

void InitUnigramTable() {
  // int a, i, word_idx;
  int a, word_idx, view_v;
  double train_words_pow = 0;
  double d1, power = 0.75;
  char *view_str, *surface_name, *word_copy;  // for parsing view and surface_name from words in vocab
  word_copy = calloc(MAX_STRING, sizeof(char));
  
  if (num_views == 0) {
    printf("Number of views must be specified\n");
    exit(1);
  }

  table = (int *)malloc(num_views * table_size_per_view * sizeof(int));

  // construct neg smp table for each view 
  for (view_v = 0; view_v < num_views; view_v++) {
    // compute partition function for this view
    train_words_pow = 0;  // re-init for each view
    for (word_idx = 1; word_idx < vocab_size; word_idx++) {  // "word_idx" starts from 1, so that </s> is not changed
      strcpy(word_copy, vocab[word_idx].word);
      // if (!strcmp(word_copy, (char *)"</s>")) continue;  // make sure to skip the view-free, colon-free </s> // handle </s> beforehand; comment out to speed up
      view_str = strtok_r(word_copy, ":", &surface_name);
      if (atoi(view_str) != view_v) continue;  // only consider current view
      train_words_pow += pow(vocab[word_idx].cn, power);
    }

    // construct map from uniformly randomly sampled variable (a) to word_idx
    for (word_idx = 1; word_idx < vocab_size; word_idx++) {  // "word_idx" starts from 1, so that </s> is not changed
      strcpy(word_copy, vocab[word_idx].word);
      // if (!strcmp(word_copy, (char *)"</s>")) continue;  // make sure to skip the view-free, colon-free </s> // handle </s> beforehand; comment out to speed up
      view_str = strtok_r(word_copy, ":", &surface_name);
      if (atoi(view_str) == view_v) break;  // first word in current view found
    }
    if (word_idx == vocab_size) {  // check if next word of cur view found in vocab
      printf("No instances of view %d in vocab\n", view_v);
      exit(1);
    }
    d1 = pow(vocab[word_idx].cn, power) / train_words_pow;
    for (a = 0; a < table_size_per_view; a++) {
      table[a + view_v * table_size_per_view] = word_idx;
      if (a / (double)table_size_per_view > d1) {
        while (word_idx < vocab_size) {
          word_idx++;
          strcpy(word_copy, vocab[word_idx].word);
          // if (!strcmp(word_copy, (char *)"</s>")) continue;  // make sure to skip the view-free, colon-free </s> // handle </s> beforehand; comment out to speed up
          view_str = strtok_r(word_copy, ":", &surface_name);
          if (atoi(view_str) == view_v) break;
        }
        d1 += pow(vocab[word_idx].cn, power) / train_words_pow;    
      }

    }
    if (word_idx >= vocab_size) word_idx = vocab_size - 1;
  }

  free(word_copy);
}

// Reads a single word from a file, assuming space + tab + EOL to be word boundaries
void ReadWord(char *word, FILE *fin) {
  int a = 0, ch;
  while (!feof(fin)) {
    ch = fgetc(fin);
    if (ch == 13) continue;
    if ((ch == ' ') || (ch == '\t') || (ch == '\n')) {
      if (a > 0) {
        if (ch == '\n') ungetc(ch, fin);
        break;
      }
      if (ch == '\n') {
        strcpy(word, (char *)"</s>");
        return;
      } else continue;
    }
    word[a] = ch;
    a++;
    if (a >= MAX_STRING - 1) a--;   // Truncate too long words
  }
  word[a] = 0;
}

// Returns hash value of a word
int GetWordHash(char *word) {
  unsigned long long a, hash = 0;
  for (a = 0; a < strlen(word); a++) hash = hash * 257 + word[a];
  hash = hash % vocab_hash_size;
  return hash;
}

// Returns position of a word in the vocabulary; if the word is not found, returns -1
int SearchVocab(char *word) {
  unsigned int hash = GetWordHash(word);
  while (1) {
    if (vocab_hash[hash] == -1) return -1;
    if (!strcmp(word, vocab[vocab_hash[hash]].word)) return vocab_hash[hash];
    hash = (hash + 1) % vocab_hash_size;
  }
  return -1;
}

// Reads a word and returns its index in the vocabulary
int ReadWordIndex(FILE *fin) {
  char word[MAX_STRING];
  ReadWord(word, fin);
  if (feof(fin)) return -1;
  return SearchVocab(word);
}

// Adds a word to the vocabulary
int AddWordToVocab(char *word) {
  unsigned int hash, length = strlen(word) + 1;
  if (length > MAX_STRING) length = MAX_STRING;
  vocab[vocab_size].word = (char *)calloc(length, sizeof(char));
  strcpy(vocab[vocab_size].word, word);
  vocab[vocab_size].cn = 0;
  vocab_size++;
  // Reallocate memory if needed
  if (vocab_size + 2 >= vocab_max_size) {
    vocab_max_size += 1000;
    vocab = (struct vocab_word *)realloc(vocab, vocab_max_size * sizeof(struct vocab_word));
  }
  hash = GetWordHash(word);
  while (vocab_hash[hash] != -1) hash = (hash + 1) % vocab_hash_size;
  vocab_hash[hash] = vocab_size - 1;
  return vocab_size - 1;
}

// Used later for sorting by word counts
int VocabCompare(const void *a, const void *b) {
    return ((struct vocab_word *)b)->cn - ((struct vocab_word *)a)->cn;
}

// Sorts the vocabulary by frequency using word counts
void SortVocab() {  // may not be necessary; without this aligning vocab with view_size is possible
  int a, size;
  unsigned int hash;
  // Sort the vocabulary and keep </s> at the first position
  qsort(&vocab[1], vocab_size - 1, sizeof(struct vocab_word), VocabCompare);
  for (a = 0; a < vocab_hash_size; a++) vocab_hash[a] = -1;
  size = vocab_size;
  train_words = 0;
  for (a = 0; a < size; a++) {
    // Words occuring less than min_count times will be discarded from the vocab
    if ((vocab[a].cn < min_count) && (a != 0)) {  // differ from google site version in whether count the one occurence of </s>
      vocab_size--;
      free(vocab[a].word);
    } else {
      // Hash will be re-computed, as after the sorting it is not actual
      hash=GetWordHash(vocab[a].word);
      while (vocab_hash[hash] != -1) hash = (hash + 1) % vocab_hash_size;
      vocab_hash[hash] = a;
      train_words += vocab[a].cn;
    }
  }
  vocab = (struct vocab_word *)realloc(vocab, (vocab_size + 1) * sizeof(struct vocab_word));
}

// Reduces the vocabulary by removing infrequent tokens
void ReduceVocab() {
  int a, b = 0;
  unsigned int hash;
  for (a = 0; a < vocab_size; a++) if (vocab[a].cn > min_reduce) {
    vocab[b].cn = vocab[a].cn;
    vocab[b].word = vocab[a].word;
    b++;
  } else free(vocab[a].word);
  vocab_size = b;
  for (a = 0; a < vocab_hash_size; a++) vocab_hash[a] = -1;
  for (a = 0; a < vocab_size; a++) {
    // Hash will be re-computed, as it is not actual
    hash = GetWordHash(vocab[a].word);
    while (vocab_hash[hash] != -1) hash = (hash + 1) % vocab_hash_size;
    vocab_hash[hash] = a;
  }
  fflush(stdout);
  min_reduce++;
}

// Create binary Huffman tree using the word counts
// Frequent words will have short uniqe binary codes
void CreateBinaryTree() {
  printf("Not BinaryTree because HS not implemented/validated for multi-view embedding.\n");
  exit(1);
}

void LearnVocabFromTrainFile() {
  char word[MAX_STRING];
  FILE *fin;
  long long a, i;
  for (a = 0; a < vocab_hash_size; a++) vocab_hash[a] = -1;
  fin = fopen(train_file, "rb");
  if (fin == NULL) {
    printf("ERROR: training data file not found!\n");
    exit(1);
  }
  vocab_size = 0;
  AddWordToVocab((char *)"</s>");
  while (1) {
    ReadWord(word, fin);
    if (feof(fin)) break;
    train_words++;
    if ((debug_mode > 1) && (train_words % 100000 == 0)) {
      printf("%lldK%c", train_words / 1000, 13);
      fflush(stdout);
    }
    i = SearchVocab(word);
    if (i == -1) {
      a = AddWordToVocab(word);
      vocab[a].cn = 1;
    } else vocab[i].cn++;
    if (vocab_size > vocab_hash_size * 0.7) ReduceVocab();
  }
  SortVocab();
  if (debug_mode > 0) {
    printf("Vocab size: %lld\n", vocab_size);
    printf("Words in train file: %lld\n", train_words);
  }
  file_size = ftell(fin);
  fclose(fin);
}

void SaveVocab() {
  long long i;
  FILE *fo = fopen(save_vocab_file, "wb");
  for (i = 0; i < vocab_size; i++) fprintf(fo, "%s %lld\n", vocab[i].word, vocab[i].cn);
  fclose(fo);
}

void ReadVocab() {
  long long a, i = 0;
  char c;
  char word[MAX_STRING];
  FILE *fin = fopen(read_vocab_file, "rb");
  if (fin == NULL) {
    printf("Vocabulary file not found\n");
    exit(1);
  }
  for (a = 0; a < vocab_hash_size; a++) vocab_hash[a] = -1;
  vocab_size = 0;
  while (1) {
    ReadWord(word, fin);
    if (feof(fin)) break;
    a = AddWordToVocab(word);
    fscanf(fin, "%lld%c", &vocab[a].cn, &c);
    i++;
  }
  SortVocab();
  if (debug_mode > 0) {
    printf("Vocab size: %lld\n", vocab_size);
    printf("Words in train file: %lld\n", train_words);
  }
  fin = fopen(train_file, "rb");
  if (fin == NULL) {
    printf("ERROR: training data file not found!\n");
    exit(1);
  }
  fseek(fin, 0, SEEK_END);
  file_size = ftell(fin);
  fclose(fin);
}

int InitNet() {
  long long a, b;
  unsigned long long next_random = 1;
  int view_v;

  char *surface_name, *word_copy, *view_str;  // for parsing view and surface_name from words in vocab
  word_copy = calloc(MAX_STRING, sizeof(char));
  char word_new[MAX_STRING];  // to scan through all views for given surface_name
  long long word_new_idx;

  real *cur_syn0 = (real *)calloc(layer1_size, sizeof(real));

  int *is_initialized = (int *)calloc(vocab_size, sizeof(int));  // record if a word is init'ed with vectors and default to 0 (not init'ed)
  neg_lock = (int *)calloc(vocab_size, sizeof(int));  // lock for each node (considering view); 1 for locked, 0 for not.
  
  a = posix_memalign((void **)&syn0, 128, (long long)vocab_size * layer1_size * sizeof(real));
  if (syn0 == NULL) {printf("Memory allocation failed\n"); exit(1);}

  if (hs) {
    printf("HS not implemented/validated for multi-view embedding.\n");
    exit(1);
  }
  if (negative>0) {
    a = posix_memalign((void **)&syn1neg, 128, (long long)vocab_size * layer1_size * sizeof(real));
    if (syn1neg == NULL) {printf("Memory allocation failed\n"); exit(1);}
    for (a = 1; a < vocab_size; a++) {  // "a" starts from 1, so that </s> is not changed
      if (is_initialized[a] == 1) continue;  // this surface name has already been initialized

      // find syn0 for current surface_name
      for (b = 0; b < layer1_size; b++) {
        next_random = next_random * (unsigned long long)25214903917 + 11;
        cur_syn0[b] = (((next_random & 0xFFFF) / (real)65536) - 0.5) / layer1_size;
      }

      strcpy(word_copy, vocab[a].word);
      // if (!strcmp(word_copy, (char *)"</s>")) continue;  // make sure to skip the view-free, colon-free </s> // handle </s> beforehand; comment out to speed up
      view_str = strtok_r(word_copy, ":", &surface_name);
      if (atoi(view_str) >= num_views) {
        printf("%s has view index outside of the specified range.\n", word_copy);
        return -1;
      }
      
      for (view_v = 0; view_v < num_views; view_v++) {
        snprintf(word_new, sizeof word_new, "%d:%s", view_v, surface_name);
        word_new_idx = SearchVocab(word_new);
        if (word_new_idx == -1) continue;
        for (b = 0; b < layer1_size; b++) {
          // init context vector
          syn1neg[word_new_idx * layer1_size + b] = 0.;
          // init word vector
          syn0[word_new_idx * layer1_size + b] = cur_syn0[b];
        }
        is_initialized[word_new_idx] = 1;
      }
      
    }
  }
  // CreateBinaryTree(); // No BinaryTree because HS is not implemented

  free(word_copy);
  free(cur_syn0);
  free(is_initialized);
  return 0;
}

void *TrainModelThread(void *id) {
  // long long a, b, d, cw, word, last_word, sentence_length = 0, sentence_position = 0;  // No cw for CBOW not implemented
  long long a, b, d, word, last_word, sentence_length = 0, sentence_position = 0;
  long long word_count = 0, last_word_count = 0, sen[MAX_SENTENCE_LENGTH + 1];
  long long l1, l2, c, target, label, local_iter = iter;
  unsigned long long next_random = (long long)id;
  int view_v, valid_view_i;

  char *view_str, *surface_name, *word_copy;  // for parsing view and surface_name from words in vocab
  word_copy = calloc(MAX_STRING, sizeof(char));
  int cur_view;

  real f, g;
  clock_t now;
  //real *neu1 = (real *)calloc(layer1_size, sizeof(real));  // No CBOW
  real *neu1e = (real *)calloc(layer1_size, sizeof(real));
  real coef_i, coef_o;  // respectively: alpha*gam*2*(|V|-1)/(|V|), alpha*gam*2*(|V|-1)/(|V|)/(1+neg)

  real *syn_sum = (real *)calloc(layer1_size, sizeof(real));  // to temporarily store the mean embedding
  int num_valid_views;  // to record the number of views that have the current node
  char word_new[MAX_STRING];  // to scan through all views for given surface_name
  long long word_new_idx;
  long long *word_new_idx_list = (long long *)calloc(num_views, sizeof(long long));

  int is_locked;
  float shared_context_delta;

  FILE *fi = fopen(train_file, "rb");
  fseek(fi, file_size / (long long)num_threads * (long long)id, SEEK_SET);
  while (1) {
    if (word_count - last_word_count > 10000) {
      word_count_actual += word_count - last_word_count;
      last_word_count = word_count;
      if ((debug_mode > 1)) {
        now=clock();
        printf("%cAlpha: %f  Progress: %.2f%%  Words/thread/sec: %.2fk  ", 13, alpha,
         word_count_actual / (real)(iter * train_words + 1) * 100,
         word_count_actual / ((real)(now - start + 1) / (real)CLOCKS_PER_SEC * 1000));
        fflush(stdout);
      }
      alpha = starting_alpha * (1 - word_count_actual / (real)(iter * train_words + 1));
      if (alpha < starting_alpha * 0.0001) alpha = starting_alpha * 0.0001;
    }
    if (sentence_length == 0) {
      while (1) {  // read one sentense from file
        word = ReadWordIndex(fi);
        if (feof(fi)) break;
        if (word == -1) continue;
        word_count++;
        if (word == 0) break;  // end of sentence since </s> is encountered, break without recording current word
        // The subsampling randomly discards frequent words while keeping the ranking same
        if (sample > 0) {
          real ran = (sqrt(vocab[word].cn / (sample * train_words)) + 1) * (sample * train_words) / vocab[word].cn;
          next_random = next_random * (unsigned long long)25214903917 + 11;
          if (ran < (next_random & 0xFFFF) / (real)65536) continue;
        }
        sen[sentence_length] = word;  // "word" is an index
        sentence_length++;
        if (sentence_length >= MAX_SENTENCE_LENGTH) break;
      }
      sentence_position = 0;
    }
    if (feof(fi) || (word_count > train_words / num_threads)) {
      word_count_actual += word_count - last_word_count;
      local_iter--;
      if (local_iter == 0) break;
      word_count = 0;
      last_word_count = 0;
      sentence_length = 0;
      fseek(fi, file_size / (long long)num_threads * (long long)id, SEEK_SET);
      continue;
    }
    word = sen[sentence_position];  // word is w_O and last_word is w_I as in p(w_O | w_I)
    if (word == -1) continue;
    
    strcpy(word_copy, vocab[word].word);
    // if (!strcmp(word_copy, (char *)"</s>")) continue;  // make sure to skip the view-free, colon-free </s> // handle </s> beforehand; comment out to speed up
    view_str = strtok_r(word_copy, ":", &surface_name);
    cur_view = atoi(view_str);

    //for (c = 0; c < layer1_size; c++) neu1[c] = 0;  // No CBOW
    for (c = 0; c < layer1_size; c++) neu1e[c] = 0;
    next_random = next_random * (unsigned long long)25214903917 + 11;
    b = next_random % window;  // randomly reduce window size
    if (cbow) {
      printf("CBOW not implemented/validated for multi-view embedding.\n");
      exit(1);
    } else {  //train skip-gram
      for (a = b; a < window * 2 + 1 - b; a++) if (a != window) {  // traverse offset within window
        c = sentence_position - window + a;
        if (c < 0) continue;
        if (c >= sentence_length) continue;
        last_word = sen[c];  // *index* of current last word 
        if (last_word == -1) continue;
        l1 = last_word * layer1_size;
        for (c = 0; c < layer1_size; c++) neu1e[c] = 0;
        // HIERARCHICAL SOFTMAX
        if (hs) {
          printf("HS not implemented/validated for multi-view embedding.\n");
          exit(1);
          /*
          for (d = 0; d < vocab[word].codelen; d++) {
          f = 0;
          l2 = vocab[word].point[d] * layer1_size;
          // Propagate hidden -> output
          for (c = 0; c < layer1_size; c++) f += syn0[c + l1] * syn1[c + l2];
          if (f <= -MAX_EXP) continue;
          else if (f >= MAX_EXP) continue;
          else f = expTable[(int)((f + MAX_EXP) * (EXP_TABLE_SIZE / MAX_EXP / 2))];
          // 'g' is the gradient multiplied by the learning rate
          g = (1 - vocab[word].code[d] - f) * alpha;
          // Propagate errors output -> hidden
          for (c = 0; c < layer1_size; c++) neu1e[c] += g * syn1[c + l2];
          // Learn weights hidden -> output
          for (c = 0; c < layer1_size; c++) syn1[c + l2] += g * syn0[c + l1];
          }
          */
        }
        // NEGATIVE SAMPLING
        if (negative > 0) {
          if (g_theta_one == 0) {  // cross-view regularize model
            for (d = 0; d < negative + 1; d++) {
              if (d == 0) {
                target = word;
                label = 1;
              } else {
                next_random = next_random * (unsigned long long)25214903917 + 11;
                target = table[(next_random >> 16) % table_size_per_view + cur_view * table_size_per_view];
                if (target == 0) {  // originally, target = next_random % (vocab_size - 1) + 1, which does not always fall on the concerned view
                  printf("ERROR: </s> unexpectedly encountered in negative sampling results. Job should be terminated.\n");
                } 
                if (target == word) continue;
                label = 0;
              }
              l2 = target * layer1_size;
              f = 0;
              for (c = 0; c < layer1_size; c++) f += syn0[c + l1] * syn1neg[c + l2];
              if (f > MAX_EXP) g = (label - 1) * alpha;
              else if (f < -MAX_EXP) g = (label - 0) * alpha;
              else g = (label - expTable[(int)((f + MAX_EXP) * (EXP_TABLE_SIZE / MAX_EXP / 2))]) * alpha;
              for (c = 0; c < layer1_size; c++) neu1e[c] += g * syn1neg[c + l2];
              for (c = 0; c < layer1_size; c++) syn1neg[c + l2] += g * syn0[c + l1];
              // regularize "target" (where word == word_O)
              for (c = 0; c < layer1_size; c++) syn_sum[c] = 0;
              num_valid_views = 0;
              strcpy(word_copy, vocab[target].word);
              // if (!strcmp(word_copy, (char *)"</s>")) continue;  // make sure to skip the view-free, colon-free </s> // handle </s> beforehand; comment out to speed up
              view_str = strtok_r(word_copy, ":", &surface_name);
              for (view_v = 0; view_v < num_views; view_v++) {
                snprintf(word_new, sizeof word_new, "%d:%s", view_v, surface_name);
                word_new_idx = SearchVocab(word_new);
                if (word_new_idx == -1) continue;
                num_valid_views++;
                for (c = 0; c < layer1_size; c++) syn_sum[c] += syn1neg[word_new_idx * layer1_size + c];  // note: we have syn1neg here
              }
              coef_o = alpha * gam * 2. * (num_valid_views - 1) / num_valid_views / (1+negative);
              for (c = 0; c < layer1_size; c++) syn1neg[c + l2] = (1-coef_o)*syn1neg[c + l2] + coef_o/num_valid_views * syn_sum[c];
            }
            // Learn weights input -> hidden
            for (c = 0; c < layer1_size; c++) syn0[c + l1] += neu1e[c];
            // regularize "last_word" (== word_I)
            for (c = 0; c < layer1_size; c++) syn_sum[c] = 0;
            num_valid_views = 0;
            strcpy(word_copy, vocab[last_word].word);
            // if (!strcmp(word_copy, (char *)"</s>")) continue;  // make sure to skip the view-free, colon-free </s> // handle </s> beforehand; comment out to speed up
            view_str = strtok_r(word_copy, ":", &surface_name);
            for (view_v = 0; view_v < num_views; view_v++) {
              snprintf(word_new, sizeof word_new, "%d:%s", view_v, surface_name);
              word_new_idx = SearchVocab(word_new);
              if (word_new_idx == -1) continue;
              num_valid_views++;
              for (c = 0; c < layer1_size; c++) syn_sum[c] += syn0[word_new_idx * layer1_size + c];  // note: we have syn0 here
            }
            coef_i = alpha * gam * 2. * (num_valid_views - 1) / num_valid_views;
            for (c = 0; c < layer1_size; c++) syn0[c + l1] = (1-coef_i)*syn0[c + l1] + coef_i/num_valid_views * syn_sum[c];
          }
          else {  // G(theta, 1) model
            for (d = 0; d < negative + 1; d++) {
              if (d == 0) {
                target = word;
                label = 1;
              } else {
                next_random = next_random * (unsigned long long)25214903917 + 11;
                target = table[(next_random >> 16) % table_size_per_view + cur_view * table_size_per_view];
                if (target == 0) {  // originally, target = next_random % (vocab_size - 1) + 1, which does not always fall on the concerned view
                  printf("ERROR: </s> unexpectedly encountered in negative sampling results. Job should be terminated.\n");
                } 
                if (target == word) continue;
                label = 0;
              }
              l2 = target * layer1_size;
              // first find all indices that corresponds to the same surface name as target
              num_valid_views = 0;
              strcpy(word_copy, vocab[target].word);
              // if (!strcmp(word_copy, (char *)"</s>")) continue;  // make sure to skip the view-free, colon-free </s> // handle </s> beforehand; comment out to speed up
              view_str = strtok_r(word_copy, ":", &surface_name);

              //pthread_mutex_lock(&lock_checking_mutex);
              num_lock_checking += 1;
              is_locked = 0;
              for (view_v = 0; view_v < num_views; view_v++) {
                snprintf(word_new, sizeof word_new, "%d:%s", view_v, surface_name);
                word_new_idx = SearchVocab(word_new);
                if (word_new_idx == -1) continue;
                word_new_idx_list[num_valid_views] = word_new_idx;
                num_valid_views++;

                // check and add lock here. 
                // ALWAYS lock from view 0 to view |V|-1, and unleck from view |V|-1 down to view 0. Only view {min_valid} is therefore effectively checked for lock
                if (neg_lock[word_new_idx] == 1) {
                  num_lock_encountering += 1;
                  is_locked = 1;
                  break;
                }
                neg_lock[word_new_idx] = 1;  // +1 for double check
              }
              //pthread_mutex_unlock(&lock_checking_mutex);
              if (is_locked == 1) continue;

              // compute the shared part of gradients
              f = 0;
              for (c = 0; c < layer1_size; c++) {
                f += syn0[c + l1] * syn1neg[c + l2] * theta;
                for (valid_view_i = 0; valid_view_i < num_valid_views; valid_view_i++)
                  f += syn0[c + l1] * syn1neg[c + word_new_idx_list[valid_view_i]*layer1_size] * ((1-theta)/num_valid_views);
              }
              if (f > MAX_EXP) g = (label - 1) * alpha;
              else if (f < -MAX_EXP) g = (label - 0) * alpha;
              else g = (label - expTable[(int)((f + MAX_EXP) * (EXP_TABLE_SIZE / MAX_EXP / 2))]) * alpha;

              // record partial gradient for word embedding of word_I
              for (c = 0; c < layer1_size; c++) {
                neu1e[c] += g * syn1neg[c + l2] * theta;
                for (valid_view_i = 0; valid_view_i < num_valid_views; valid_view_i++)
                  neu1e[c] += g * syn1neg[c + word_new_idx_list[valid_view_i]*layer1_size] * ((1-theta)/num_valid_views);
              }

              // update context embedding of word_O in each view
              for (c = 0; c < layer1_size; c++) {
                syn1neg[c + l2] += g * syn0[c + l1] * theta;
                shared_context_delta = g * syn0[c + l1] * ((1-theta)/num_valid_views);
                for (valid_view_i = 0; valid_view_i < num_valid_views; valid_view_i++)
                  syn1neg[c + word_new_idx_list[valid_view_i]*layer1_size] += shared_context_delta;///
              }

              // release lock here, from view |V|-1 down to view 0.
              //pthread_mutex_lock(&lock_releasing_mutex);
              for (valid_view_i = num_valid_views-1; valid_view_i >=0; valid_view_i--)
                neg_lock[word_new_idx_list[valid_view_i]] = 0;
              //pthread_mutex_unlock(&lock_releasing_mutex);
            }
            // Learn weights input -> hidden
            for (c = 0; c < layer1_size; c++) syn0[c + l1] += neu1e[c];
          }
        }
      }
    }
    sentence_position++;
    if (sentence_position >= sentence_length) {  // reset and read a new sentence
      sentence_length = 0;
      continue;
    }
  }
  fclose(fi);
  //free(neu1);  // No CBOW
  free(neu1e);
  free(syn_sum);
  free(word_copy);
  pthread_exit(NULL);
}

void TrainModel() {
  // long a, b, c, d;
  long a, b;
  FILE *fo, *fo_context;
  int init_net_signal;
  pthread_t *pt = (pthread_t *)malloc(num_threads * sizeof(pthread_t));
  printf("Starting training using file %s\n", train_file);
  starting_alpha = alpha;
  if (read_vocab_file[0] != 0) ReadVocab(); else LearnVocabFromTrainFile();
  if (save_vocab_file[0] != 0) SaveVocab();
  if (output_file[0] == 0) return;
  init_net_signal = InitNet();
  if (init_net_signal == -1) return;
  if (negative > 0) InitUnigramTable();
  start = clock();
  for (a = 0; a < num_threads; a++) pthread_create(&pt[a], NULL, TrainModelThread, (void *)a);
  for (a = 0; a < num_threads; a++) pthread_join(pt[a], NULL);

  if (output_file_context[0] != 0) {
    fo_context = fopen(output_file_context, "wb");
    fprintf(fo_context, "%lld %lld\n", vocab_size-1, layer1_size);  // -1 to exclude </s>
    printf("Assume </s> is sorted to the beginning and thereby neglected in the context output.\n");
    for (a = 1; a < vocab_size; a++) { // Assume </s> is sorted to the beginning and thereby neglected in the output
      fprintf(fo_context, "%s ", vocab[a].word);
      if (binary) for (b = 0; b < layer1_size; b++) fwrite(&syn1neg[a * layer1_size + b], sizeof(real), 1, fo_context);
      else for (b = 0; b < layer1_size; b++) fprintf(fo_context, "%lf ", syn1neg[a * layer1_size + b]);
      fprintf(fo_context, "\n");
    }
    fclose(fo_context);
  }

  fo = fopen(output_file, "wb");
  if (classes == 0) {
    // Save the word vectors
    fprintf(fo, "%lld %lld\n", vocab_size-1, layer1_size);  // -1 to exclude </s>
    printf("Assume </s> is sorted to the beginning and thereby neglected in the output.\n");
    for (a = 1; a < vocab_size; a++) { // Assume </s> is sorted to the beginning and thereby neglected in the output
      fprintf(fo, "%s ", vocab[a].word);
      if (binary) for (b = 0; b < layer1_size; b++) fwrite(&syn0[a * layer1_size + b], sizeof(real), 1, fo);
      else for (b = 0; b < layer1_size; b++) fprintf(fo, "%lf ", syn0[a * layer1_size + b]);
      fprintf(fo, "\n");
    }
  } else {
    printf("K-means not implemented/validated for multi-view embedding.\n");
    exit(1);
  }
  fclose(fo);
}

int ArgPos(char *str, int argc, char **argv) {
  int a;
  for (a = 1; a < argc; a++) if (!strcmp(str, argv[a])) {
    if (a == argc - 1) {
      printf("Argument missing for %s\n", str);
      exit(1);
    }
    return a;
  }
  return -1;
}

int main(int argc, char **argv) {
  int i;
  if (argc == 1) {
    printf("WORD VECTOR estimation toolkit v 0.1c\n\n");
    printf("Options:\n");
    printf("Parameters for training:\n");
    printf("\t-train <file>\n");
    printf("\t\tUse text data from <file> to train the model\n");
    printf("\t-output <file>\n");
    printf("\t\tUse <file> to save the resulting word vectors / word clusters\n");
    printf("\t-output-context <file>\n");
    printf("\t\tUse <file> to save the resulting context vectors\n");
    printf("\t-size <int>\n");
    printf("\t\tSet size of word vectors; default is 100\n");
    printf("\t-window <int>\n");
    printf("\t\tSet max skip length between words; default is 5\n");
    printf("\t-sample <float>\n");
    printf("\t\tSet threshold for occurrence of words. Those that appear with higher frequency in the training data\n");
    printf("\t\twill be randomly down-sampled; default is 1e-3, useful range is (0, 1e-5)\n");
    printf("\t-hs <int>\n");
    printf("\t\tUse Hierarchical Softmax; default is 0 (not used)\n");
    printf("\t-negative <int>\n");
    printf("\t\tNumber of negative examples; default is 5, common values are 3 - 10 (0 = not used)\n");
    printf("\t-threads <int>\n");
    printf("\t\tUse <int> threads (default 12)\n");
    printf("\t-iter <int>\n");
    printf("\t\tRun more training iterations (default 5)\n");
    printf("\t-min-count <int>\n");
    printf("\t\tThis will discard words that appear less than <int> times; default is 5\n");
    printf("\t-alpha <float>\n");
    printf("\t\tSet the starting learning rate; default is 0.025 for skip-gram and 0.05 for CBOW\n");
    printf("\t-classes <int>\n");
    printf("\t\tOutput word classes rather than word vectors; default number of classes is 0 (vectors are written)\n");
    printf("\t-debug <int>\n");
    printf("\t\tSet the debug mode (default = 2 = more info during training)\n");
    printf("\t-binary <int>\n");
    printf("\t\tSave the resulting vectors in binary moded; default is 0 (off)\n");
    printf("\t-save-vocab <file>\n");
    printf("\t\tThe vocabulary will be saved to <file>\n");
    printf("\t-read-vocab <file>\n");
    printf("\t\tThe vocabulary will be read from <file>, not constructed from the training data\n");
    printf("\t-cbow <int>\n");
    printf("\t\tUse the continuous bag of words model; default is 0 (use 0 for skip-gram model)\n");
    printf("\t-g-theta-one <int>\n");
    printf("\t\tUse the G(theta, 1) model; default is 0 (use 0 for cross-view regularization model)\n");
    printf("\t-views <int>\n");
    printf("\t\tNumber of views in the input network. The view indices must be 0, 1, ..., (num_views - 1).\n");
    printf("\nExamples:\n");
    printf("./mvn2vec -views 8 -train data.txt -output vec.txt -size 200 -window 5 -sample 1e-4 -negative 5 -hs 0 -binary 0 -cbow 0 -iter 1\n\n");
    printf("\t-gamma <float>\n");
    printf("\t\tSet the regularization parameter; default is 0.1\n");
    printf("\t-theta <float>\n");
    printf("\t\tSet theta as in the G(theta, 1) model; default is 0.0\n");
    return 0;
  }
  output_file[0] = 0;
  output_file_context[0] = 0;
  save_vocab_file[0] = 0;
  read_vocab_file[0] = 0;
  if ((i = ArgPos((char *)"-size", argc, argv)) > 0) layer1_size = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-train", argc, argv)) > 0) strcpy(train_file, argv[i + 1]);
  if ((i = ArgPos((char *)"-save-vocab", argc, argv)) > 0) strcpy(save_vocab_file, argv[i + 1]);
  if ((i = ArgPos((char *)"-read-vocab", argc, argv)) > 0) strcpy(read_vocab_file, argv[i + 1]);
  if ((i = ArgPos((char *)"-debug", argc, argv)) > 0) debug_mode = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-binary", argc, argv)) > 0) binary = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-cbow", argc, argv)) > 0) cbow = atoi(argv[i + 1]);
  if (cbow) alpha = 0.05;
  if ((i = ArgPos((char *)"-alpha", argc, argv)) > 0) alpha = atof(argv[i + 1]);
  if ((i = ArgPos((char *)"-output", argc, argv)) > 0) strcpy(output_file, argv[i + 1]);
  if ((i = ArgPos((char *)"-output-context", argc, argv)) > 0) strcpy(output_file_context, argv[i + 1]);
  if ((i = ArgPos((char *)"-window", argc, argv)) > 0) window = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-sample", argc, argv)) > 0) sample = atof(argv[i + 1]);
  if ((i = ArgPos((char *)"-hs", argc, argv)) > 0) hs = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-negative", argc, argv)) > 0) negative = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-threads", argc, argv)) > 0) num_threads = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-iter", argc, argv)) > 0) iter = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-min-count", argc, argv)) > 0) min_count = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-classes", argc, argv)) > 0) classes = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-views", argc, argv)) > 0) num_views = atoi(argv[i + 1]);
  if ((i = ArgPos((char *)"-gamma", argc, argv)) > 0) gam = atof(argv[i + 1]);
  if ((i = ArgPos((char *)"-theta", argc, argv)) > 0) theta = atof(argv[i + 1]);
  if ((i = ArgPos((char *)"-g-theta-one", argc, argv)) > 0) g_theta_one = atoi(argv[i + 1]);
  vocab = (struct vocab_word *)calloc(vocab_max_size, sizeof(struct vocab_word));
  vocab_hash = (int *)calloc(vocab_hash_size, sizeof(int));
  expTable = (real *)malloc((EXP_TABLE_SIZE + 1) * sizeof(real));
  for (i = 0; i < EXP_TABLE_SIZE; i++) {
    expTable[i] = exp((i / (real)EXP_TABLE_SIZE * 2 - 1) * MAX_EXP); // Precompute the exp() table
    expTable[i] = expTable[i] / (expTable[i] + 1);                   // Precompute f(x) = x / (x + 1)
  }
  TrainModel();
  free(neg_lock);
  printf("Number of lock encountering: %lld out of %lld times of checking.\n", num_lock_encountering, num_lock_checking);
  return 0;
}
