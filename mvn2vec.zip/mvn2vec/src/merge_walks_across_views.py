import sys

input_file_list = sys.argv[1:-1]
output_file_prefix = sys.argv[-1]

output_file_view_index = output_file_prefix + "_view_index.txt"
output_file_plain_uniform = output_file_prefix + "_plain.walks"
output_file_typed_uniform = output_file_prefix + "_typed.walks"

"""
Record view index
"""
num_views = len(input_file_list)
with open(output_file_view_index, "w") as f_out:
    for idx in xrange(num_views):
        f_out.write(str(idx) + "\t" + input_file_list[idx] + "\n")

"""
Read walks from each view
"""
walks_plain_list = []
walks_typed_list = []
num_line = 0
for idx, input_file in enumerate(input_file_list):
    cur_walks_plain = []
    cur_walks_typed = []
    with open(input_file, "r") as f_in:
        for line in f_in:
            line_strip = line.strip()
            cur_walks_plain.append(line_strip + "\n")
            cur_walks_typed.append(" ".join(map(lambda x: str(idx) + ":" + x, line_strip.split(" "))) + "\n")
            num_line += 1
            if num_line % 10000 == 0:
                print "Line %d read." % num_line
    walks_plain_list.append(cur_walks_plain)
    walks_typed_list.append(cur_walks_typed)

print "Read walks done."

"""
Generate the merged walks with uniform view weights
"""
num_walks_per_view = map(len, walks_plain_list)
max_num_walks_per_view = max(num_walks_per_view)
with open(output_file_plain_uniform, "w") as f_out_plain, open(output_file_typed_uniform, "w") as f_out_typed:
    for walk_i in xrange(max_num_walks_per_view):
        for view_idx in xrange(num_views):
            f_out_plain.write(walks_plain_list[view_idx][walk_i % num_walks_per_view[view_idx]])
            f_out_typed.write(walks_typed_list[view_idx][walk_i % num_walks_per_view[view_idx]])
