#!/bin/bash

data_name=$1 # including net gen parameters; also serve as directory name

num_threads=4

window_size=3
num_views=2
data_origin="synthetic"

src_dir=./src
data_dir=./data/synthetic/"$data_name"
mvn2vec_dir=./src/mvn2vec/bin

time_start=$(date +"%Y%m%d_%H%M%S")

## random walk
view_name_list="black red"
for view_name in $view_name_list
do
	(
		python $src_dir/sample_walks.py --unweighted --input "$data_dir"/network_synthetic_"$view_name".edgelist --output "$data_dir"/network_synthetic_"$view_name".walks  # edgelists are generated with networkx with data=False
	) &
done
wait


## merge
walk_files=""
for view_name in $view_name_list
do
	walk_files="$walk_files $data_dir/network_synthetic_"$view_name".walks"
done

python $src_dir/merge_walks_across_views.py $walk_files "$data_dir"/multi_view_network_synthetic 

## embed
for gam in 0.02 0.05 0.1 0.12 0.15 0.2 0.5 1. 2. 5.
do 
	echo "Start training: mvn2vec regularization (gamma = $gam, *_reg_*)"
	time "$mvn2vec_dir"/mvn2vec -views "$num_views" -train "$data_dir"/multi_view_network_"$data_origin"_typed.walks -output "$data_dir"/multi_view_reg_embedding_"$data_origin".gamma"$gam".emb -size 128 -negative 5 -threads "$num_threads" -iter 1 -gamma "$gam" -window "$window_size"
done

for theta in 0.0 0.1 0.5 0.9 1.0
do 
	echo "Start training: mvn2vec g(theta, 1) (theta = $theta, *_con_*)"
	time "$mvn2vec_dir"/mvn2vec -views "$num_views" -train "$data_dir"/multi_view_network_"$data_origin"_typed.walks -output "$data_dir"/multi_view_con_embedding_"$data_origin".theta"$theta".emb -size 128 -negative 5 -threads "$num_threads" -iter 1 -g-theta-one 1 -theta "$theta" -window "$window_size"
done

## normalize
for emb_file in $data_dir/*_embedding_"$data_origin"*.emb
do
	(
	time python $src_dir/normalize_embedding.py "$emb_file"
	) &
done
wait

## concatenate
for emb_file_to_concat in $data_dir/multi_view_*_embedding_"$data_origin"*.emb
do
	(
	time python $src_dir/concatenate_embedding_from_views.py "$emb_file_to_concat"
	) &
done
wait


## evaluate
echo "Regularization coefficient (c) should be further tuned for each model beyond the for-loop in this example script to achieve fair evaluation result."
for c in 1. 2. 5. 10. 20.
do
	output_dir="./output/synthetic_multi_class_evaluation/"$data_name"_$time_start"/c"$c"

	mkdir -p $output_dir
	cat "$(basename "$(test -L "$0" && readlink "$0" || echo "$0")")" > $output_dir/run_used.txt

	for seed in 31 41 59 26 53
	do
		for emb_file in $data_dir/concat*"$data_origin"*theta*norm*.emb $data_dir/concat*"$data_origin"*gamma*norm*.emb
		do
		    python $src_dir/multi_class_eval.py --input-embedding $emb_file --input-label $data_dir/synthetic_evaluation_core.csv --output-dir $output_dir --seed $seed --c $c
		done
	done

	python $src_dir/output_parser.py $output_dir/
done
